package com.vti.dto;

import com.vti.entity.User;

public class UserDTO {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public UserDTO() {
	}

	public User toEntity() {
		return new User();
	}
}
