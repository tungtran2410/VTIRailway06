package com.vti.dto;

import com.vti.entity.Group;
import com.vti.entity.Group;

public class GroupDTO {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public GroupDTO() {
	}

	public Group toEntity() {
		return new Group();
	}	
}
