package com.vti.service;

import java.util.List;

import java.io.FileWriter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.vti.entity.Filter;
import com.vti.entity.User;
import com.vti.repository.IUserRepository;

@Service
public class UserService implements IUserService{


	@Autowired
	private IUserRepository repository;
	@Override
	public List<User> getAllUsers(long page, long pageSize, Filter filter) {
		// TODO Auto-generated method stub
		Specification<User> where = null;
		
		
		if(filter.getSearch() != null && filter.getSearch().isBlank() && Filter.getSearch().isEmpty()) {
			if(where == null) { 
				where = searchbyName(filter.getSearch());
			} else {
				where = where.and(searchbyName(filter.getSearch()));
			}
		}
		Pageable pageable = PageRequest.of((int)page, (int)pageSize);
		return repository.findAll(where,pageable).toList();
		
	}

	private Specification<User> searchbyName(String search) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserByID(short id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserByName(String name) {
		// TODO Auto-generated method stub
		return repository.findByUsername(name);
	}

	@Override
	public void createUser(User User) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateUser(User User) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(short id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isUserExistsByID(short id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isUserExistsByName(String name) {
		// TODO Auto-generated method stub
		return false;
	}
}
