package com.vti.service;

import java.util.List;

import com.vti.entity.Filter;
import com.vti.entity.Group;

public interface IGroupService {

	public List<Group> getAllGroups(long page, long pageSize, Filter filter);

	public Group getGroupByID(short id);

	public Group getGroupByName(String name);

	public void createGroup(Group Group);

	public void updateGroup(Group Group);

	public void deleteGroup(short id);

//	public boolean isGroupExistsByID(short id);
//
//	public boolean isGroupExistsByName(String name);

}
