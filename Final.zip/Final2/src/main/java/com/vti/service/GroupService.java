package com.vti.service;

import java.io.FileWriter;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.vti.entity.Group;
import com.vti.repository.IGroupRepository;
import com.vti.entity.Filter;
import com.vti.entity.Group;

@Service
public class GroupService implements IGroupService {

	@Autowired
	private IGroupRepository repository;
	
	@Override
	public List<Group> getAllGroups(long page, long pageSize, Filter filter) {
		// TODO Auto-generated method stub
		Specification<Group> where = null;
		
		
		if(filter.getSearch() != null && !filter.getSearch().isBlank() && !Filter.getSearch().isEmpty()) {
			if(where == null) { 
				where = searchbyName(filter.getSearch());
			} else {
				where = where.and(searchbyName(filter.getSearch()));
			}
		}
		Pageable pageable = PageRequest.of((int)page, (int)pageSize);
		return repository.findAll(where,pageable).toList();
	}

	private Specification<Group> searchbyName(String search) {
		// TODO Auto-generated method stub
		return new Specification<Group>() {
			@Override
			public Predicate toPredicate(Root<Group> root, CriteriaQuery<?> query,
					CriteriaBuilder criteriaBuilder) {
				return criteriaBuilder.like(root.get("groupname"), "%"+search+"%");
			}
		};		
	}

	public Specification<Group> searchGroup(String search) {
		return new Specification<Group>() {
			
			@Override
			public Predicate toPredicate(Root<Group> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				return criteriaBuilder.like(root.get("groupname"), "%" + search + "%");
			}

		};
	}

	@Override
	public Group getGroupByID(short id) {
		return null;
	}

	@Override
	public Group getGroupByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createGroup(Group Group) {
		repository.save(Group);
	}

	@Override
	public void updateGroup(Group Group) {
		// TODO Auto-generated method stub
		repository.save(Group);
		
	}

	@Override
	public void deleteGroup(short id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

//	@Override
//	public boolean isGroupExistsByID(short id) {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	@Override
//	public boolean isGroupExistsByName(String name) {
//		// TODO Auto-generated method stub
//		return false;
	}


	


