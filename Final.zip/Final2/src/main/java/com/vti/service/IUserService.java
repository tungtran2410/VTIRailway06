package com.vti.service;

import java.util.List;

import com.vti.entity.Filter;
import com.vti.entity.User;

public interface IUserService {
	public List<User> getAllUsers(long page, long pageSize, Filter filter);

	public User getUserByID(short id);

	public User getUserByName(String name);

	public void createUser(User User);

	public void updateUser(User User);

	public void deleteUser(short id);

	public boolean isUserExistsByID(short id);

	public boolean isUserExistsByName(String name);
}
