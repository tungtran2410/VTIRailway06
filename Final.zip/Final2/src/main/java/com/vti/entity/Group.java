package com.vti.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "Group", catalog = "TestingSystem")
public class Group {
	
	@Column(name = "GroupID")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private short id;
	
	@Column(name = "GroupName", length = 30, nullable = false, unique = true)
	private String groupname;
	
	@Column(name = "Member", nullable = false)
	private int member;
	
	public Group(short id, String groupname, int member, Date createdate, User creator) {
		super();
		this.id = id;
		this.groupname = groupname;
		this.member = member;
		this.createdate = createdate;
		this.creator = creator;
	}

	@Column(name = "CreateDate", nullable = false)
	@CreationTimestamp
	private Date createdate;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CreatorID",referencedColumnName = "id",nullable = false)
	private User creator;

	public short getId() {
		return id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public int getMember() {
		return member;
	}

	public void setMember(int member) {
		this.member = member;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public User getCreator() {
		return creator;
	}

	public void setCreator(User creator) {
		this.creator = creator;
	}

	@Override
	public String toString() {
		return "Group [id=" + id + ", groupname=" + groupname + ", member=" + member + ", createdate=" + createdate
				+ ", creator=" + creator + "]";
	}

	public Group() {
		super();
	}
	
}
