package com.vti.entity;

public class Filter {
	private static String search;
	
	private int minMember;
	
	private int maxMember;

	public static String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public int getMinMember() {
		return minMember;
	}

	public void setMinMember(int minMember) {
		this.minMember = minMember;
	}

	public int getMaxMember() {
		return maxMember;
	}

	public void setMaxMember(int maxMember) {
		this.maxMember = maxMember;
	}

	@Override
	public String toString() {
		return "Fillter [search=" + search + ", minMember=" + minMember + ", maxMember=" + maxMember + "]";
	}
	
	
}
