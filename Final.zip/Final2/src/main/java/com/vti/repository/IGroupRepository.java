package com.vti.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.cdi.JpaRepositoryExtension;

import com.vti.entity.Group;

public interface IGroupRepository extends JpaRepository<Group, Short>, JpaSpecificationExecutor<Group>{ 
	
//	public Group findbyName (String name);
//	
//	public boolean exitsbyName (String name);

}
